from sqlalchemy.orm import Session as DBSession
from sqlalchemy import desc
from datetime import date, datetime, timedelta
import models, schemas
from models import MILESTONE_DAYS


# ── Auth / Users ──────────────────────────────────────────────────────────────

def get_user_by_email(db: DBSession, email: str):
    return db.query(models.User).filter(models.User.email == email).first()

def get_user_by_google_id(db: DBSession, google_id: str):
    return db.query(models.User).filter(models.User.google_id == google_id).first()

def create_user(db: DBSession, email: str, hashed_password=None, username=None, google_id=None, avatar_url=None):
    user = models.User(
        email=email,
        hashed_password=hashed_password,
        username=username,
        google_id=google_id,
        avatar_url=avatar_url,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    # Create default settings for user
    settings = models.Settings(user_id=user.id)
    db.add(settings)
    db.commit()
    return user


# ── Settings ──────────────────────────────────────────────────────────────────

def get_or_create_settings(db: DBSession, user_id: int) -> models.Settings:
    s = db.query(models.Settings).filter_by(user_id=user_id).first()
    if not s:
        s = models.Settings(user_id=user_id)
        db.add(s)
        db.commit()
        db.refresh(s)
    return s

def update_settings(db: DBSession, user_id: int, payload: schemas.SettingsUpdate) -> models.Settings:
    s = get_or_create_settings(db, user_id)
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(s, field, value)
    db.commit()
    db.refresh(s)
    return s


# ── Sessions ──────────────────────────────────────────────────────────────────

def list_sessions(db: DBSession, user_id: int, limit=50, offset=0):
    return (
        db.query(models.Session)
        .filter_by(user_id=user_id)
        .order_by(desc(models.Session.created_at))
        .offset(offset).limit(limit).all()
    )

def create_session(db: DBSession, user_id: int, payload: schemas.SessionCreate):
    session = models.Session(user_id=user_id, **payload.model_dump())
    db.add(session)
    db.commit()
    db.refresh(session)

    # Update streak if this is a completed work session
    new_milestone = None
    if payload.mode == "work" and payload.completed:
        new_milestone = _update_streak(db, user_id)

    return session, new_milestone

def delete_session(db: DBSession, user_id: int, session_id: int) -> bool:
    s = db.query(models.Session).filter_by(id=session_id, user_id=user_id).first()
    if not s:
        return False
    db.delete(s)
    db.commit()
    return True


# ── Streak ────────────────────────────────────────────────────────────────────

def _update_streak(db: DBSession, user_id: int) -> int | None:
    """Update the user's daily streak. Returns milestone days if just unlocked, else None."""
    user = db.query(models.User).filter_by(id=user_id).first()
    today = date.today()
    yesterday = today - timedelta(days=1)
    new_milestone = None

    if user.last_active_date == today:
        # Already counted today
        pass
    elif user.last_active_date == yesterday:
        # Consecutive day — extend streak
        user.current_streak += 1
    else:
        # Streak broken or first session ever
        user.current_streak = 1

    user.last_active_date = today

    if user.current_streak > user.longest_streak:
        user.longest_streak = user.current_streak

    # Check milestones
    for days in MILESTONE_DAYS:
        if user.current_streak == days:
            already = db.query(models.Milestone).filter_by(user_id=user_id, days=days).first()
            if not already:
                db.add(models.Milestone(user_id=user_id, days=days))
                new_milestone = days

    db.commit()
    return new_milestone


# ── Stats ─────────────────────────────────────────────────────────────────────

def get_stats(db: DBSession, user_id: int) -> schemas.Stats:
    user = db.query(models.User).filter_by(id=user_id).first()
    all_sessions = db.query(models.Session).filter_by(user_id=user_id).all()
    milestones = db.query(models.Milestone).filter_by(user_id=user_id).all()
    today = date.today()

    return schemas.Stats(
        total_sessions=len(all_sessions),
        completed_sessions=sum(1 for s in all_sessions if s.completed),
        total_focus_min=sum(s.duration_min for s in all_sessions if s.mode=="work" and s.completed),
        current_streak=user.current_streak,
        longest_streak=user.longest_streak,
        today_sessions=sum(1 for s in all_sessions if s.created_at.date()==today),
        today_focus_min=sum(s.duration_min for s in all_sessions if s.mode=="work" and s.completed and s.created_at.date()==today),
        milestones=[schemas.Milestone.model_validate(m) for m in milestones],
    )
