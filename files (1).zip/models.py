from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Date
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base


class User(Base):
    __tablename__ = "users"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    email           = Column(String, unique=True, nullable=False, index=True)
    username        = Column(String, nullable=True)
    hashed_password = Column(String, nullable=True)
    google_id       = Column(String, nullable=True, unique=True)
    avatar_url      = Column(String, nullable=True)
    current_streak   = Column(Integer, default=0)
    longest_streak   = Column(Integer, default=0)
    last_active_date = Column(Date, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    sessions   = relationship("Session",   back_populates="user", cascade="all, delete-orphan")
    settings   = relationship("Settings",  back_populates="user", uselist=False, cascade="all, delete-orphan")
    milestones = relationship("Milestone", back_populates="user", cascade="all, delete-orphan")


class Settings(Base):
    __tablename__ = "settings"

    id                = Column(Integer, primary_key=True, autoincrement=True)
    user_id           = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    work_minutes      = Column(Integer, default=25)
    short_minutes     = Column(Integer, default=5)
    long_minutes      = Column(Integer, default=15)
    sessions_per_long = Column(Integer, default=4)
    auto_start        = Column(Boolean, default=False)
    sound_enabled     = Column(Boolean, default=True)
    theme             = Column(String, default="dark")
    shape             = Column(String, default="circle")
    updated_at        = Column(DateTime, server_default=func.now(), onupdate=func.now())

    user = relationship("User", back_populates="settings")


class Session(Base):
    __tablename__ = "sessions"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    user_id      = Column(Integer, ForeignKey("users.id"), nullable=False)
    mode         = Column(String, nullable=False)
    duration_min = Column(Integer, nullable=False)
    completed    = Column(Boolean, default=True)
    note         = Column(String, nullable=True)
    created_at   = Column(DateTime, server_default=func.now())

    user = relationship("User", back_populates="sessions")


MILESTONE_DAYS = [7, 30, 100]

class Milestone(Base):
    __tablename__ = "milestones"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    user_id     = Column(Integer, ForeignKey("users.id"), nullable=False)
    days        = Column(Integer, nullable=False)
    achieved_at = Column(DateTime, server_default=func.now())

    user = relationship("User", back_populates="milestones")
