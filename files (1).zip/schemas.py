from pydantic import BaseModel, Field, EmailStr
from datetime import datetime, date
from typing import Optional, Literal


# ── Auth ──────────────────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=6)
    username: Optional[str] = None

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserPublic"

class UserPublic(BaseModel):
    id: int
    email: str
    username: Optional[str]
    avatar_url: Optional[str]
    current_streak: int
    longest_streak: int
    class Config:
        from_attributes = True

TokenResponse.model_rebuild()


# ── Settings ──────────────────────────────────────────────────────────────────

class Settings(BaseModel):
    id: int
    work_minutes: int
    short_minutes: int
    long_minutes: int
    sessions_per_long: int
    auto_start: bool
    sound_enabled: bool
    theme: str
    shape: str
    updated_at: Optional[datetime]
    class Config:
        from_attributes = True

class SettingsUpdate(BaseModel):
    work_minutes:      Optional[int]   = Field(None, ge=1, le=60)
    short_minutes:     Optional[int]   = Field(None, ge=1, le=30)
    long_minutes:      Optional[int]   = Field(None, ge=1, le=60)
    sessions_per_long: Optional[int]   = Field(None, ge=1, le=8)
    auto_start:        Optional[bool]  = None
    sound_enabled:     Optional[bool]  = None
    theme:             Optional[Literal["dark", "light"]] = None
    shape:             Optional[Literal["circle", "square", "minimal"]] = None


# ── Sessions ──────────────────────────────────────────────────────────────────

class SessionCreate(BaseModel):
    mode:         Literal["work", "short", "long"]
    duration_min: int = Field(..., ge=1, le=120)
    completed:    bool = True
    note:         Optional[str] = Field(None, max_length=200)

class Session(BaseModel):
    id:           int
    mode:         str
    duration_min: int
    completed:    bool
    note:         Optional[str]
    created_at:   datetime
    class Config:
        from_attributes = True


# ── Stats ─────────────────────────────────────────────────────────────────────

class Milestone(BaseModel):
    days:        int
    achieved_at: datetime
    class Config:
        from_attributes = True

class Stats(BaseModel):
    total_sessions:     int
    completed_sessions: int
    total_focus_min:    int
    current_streak:     int
    longest_streak:     int
    today_sessions:     int
    today_focus_min:    int
    milestones:         list[Milestone]
    new_milestone:      Optional[int] = None   # set when a milestone was just unlocked
