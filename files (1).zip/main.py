from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session as DBSession
import httpx

import models, schemas, crud, auth
from database import SessionLocal, engine
from config import (
    GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET,
    GOOGLE_REDIRECT_URI, FRONTEND_URL,
    ACCESS_TOKEN_EXPIRE_MINUTES
)
from auth import (
    hash_password, verify_password,
    create_access_token, get_current_user, get_db
)
from datetime import timedelta

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Pomodoro API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Auth: Email/Password ──────────────────────────────────────────────────────

@app.post("/auth/register", response_model=schemas.TokenResponse, tags=["Auth"])
def register(payload: schemas.RegisterRequest, db: DBSession = Depends(get_db)):
    if crud.get_user_by_email(db, payload.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    user = crud.create_user(
        db,
        email=payload.email,
        hashed_password=hash_password(payload.password),
        username=payload.username,
    )
    token = create_access_token(user.id, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    return schemas.TokenResponse(access_token=token, user=schemas.UserPublic.model_validate(user))


@app.post("/auth/login", response_model=schemas.TokenResponse, tags=["Auth"])
def login(payload: schemas.LoginRequest, db: DBSession = Depends(get_db)):
    user = crud.get_user_by_email(db, payload.email)
    if not user or not user.hashed_password or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_access_token(user.id, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    return schemas.TokenResponse(access_token=token, user=schemas.UserPublic.model_validate(user))


@app.get("/auth/me", response_model=schemas.UserPublic, tags=["Auth"])
def me(current_user: models.User = Depends(get_current_user)):
    return current_user


# ── Auth: Google OAuth ────────────────────────────────────────────────────────

GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v3/userinfo"

@app.get("/auth/google", tags=["Auth"])
def google_login():
    """Redirect user to Google OAuth consent screen."""
    if not GOOGLE_CLIENT_ID:
        raise HTTPException(status_code=501, detail="Google OAuth not configured")
    params = (
        f"?client_id={GOOGLE_CLIENT_ID}"
        f"&redirect_uri={GOOGLE_REDIRECT_URI}"
        f"&response_type=code"
        f"&scope=openid%20email%20profile"
        f"&access_type=offline"
    )
    return RedirectResponse(GOOGLE_AUTH_URL + params)


@app.get("/auth/google/callback", tags=["Auth"])
async def google_callback(code: str = Query(...), db: DBSession = Depends(get_db)):
    """Exchange code for token, upsert user, redirect to frontend with JWT."""
    if not GOOGLE_CLIENT_ID:
        raise HTTPException(status_code=501, detail="Google OAuth not configured")

    async with httpx.AsyncClient() as client:
        # Exchange code for tokens
        token_resp = await client.post(GOOGLE_TOKEN_URL, data={
            "code": code,
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "redirect_uri": GOOGLE_REDIRECT_URI,
            "grant_type": "authorization_code",
        })
        token_data = token_resp.json()
        access_token_google = token_data.get("access_token")

        # Fetch user info
        user_resp = await client.get(
            GOOGLE_USERINFO_URL,
            headers={"Authorization": f"Bearer {access_token_google}"}
        )
        info = user_resp.json()

    google_id  = info.get("sub")
    email      = info.get("email")
    name       = info.get("name")
    avatar_url = info.get("picture")

    # Upsert user
    user = crud.get_user_by_google_id(db, google_id)
    if not user:
        user = crud.get_user_by_email(db, email)
        if user:
            user.google_id  = google_id
            user.avatar_url = avatar_url
            db.commit()
        else:
            user = crud.create_user(db, email=email, username=name, google_id=google_id, avatar_url=avatar_url)

    jwt_token = create_access_token(user.id, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    return RedirectResponse(f"{FRONTEND_URL}?token={jwt_token}")


# ── Settings ──────────────────────────────────────────────────────────────────

@app.get("/settings", response_model=schemas.Settings, tags=["Settings"])
def get_settings(current_user=Depends(get_current_user), db: DBSession = Depends(get_db)):
    return crud.get_or_create_settings(db, current_user.id)

@app.put("/settings", response_model=schemas.Settings, tags=["Settings"])
def update_settings(payload: schemas.SettingsUpdate, current_user=Depends(get_current_user), db: DBSession = Depends(get_db)):
    return crud.update_settings(db, current_user.id, payload)


# ── Sessions ──────────────────────────────────────────────────────────────────

@app.get("/sessions", response_model=list[schemas.Session], tags=["Sessions"])
def list_sessions(limit: int = 50, offset: int = 0, current_user=Depends(get_current_user), db: DBSession = Depends(get_db)):
    return crud.list_sessions(db, current_user.id, limit=limit, offset=offset)

@app.post("/sessions", response_model=schemas.Session, status_code=201, tags=["Sessions"])
def create_session(payload: schemas.SessionCreate, current_user=Depends(get_current_user), db: DBSession = Depends(get_db)):
    session, new_milestone = crud.create_session(db, current_user.id, payload)
    resp = schemas.Session.model_validate(session)
    # Attach new_milestone as a custom header so the frontend can show the popup
    from fastapi.responses import JSONResponse
    data = resp.model_dump()
    data["new_milestone"] = new_milestone
    return JSONResponse(content=data, status_code=201)

@app.delete("/sessions/{session_id}", status_code=204, tags=["Sessions"])
def delete_session(session_id: int, current_user=Depends(get_current_user), db: DBSession = Depends(get_db)):
    if not crud.delete_session(db, current_user.id, session_id):
        raise HTTPException(status_code=404, detail="Session not found")


# ── Stats ─────────────────────────────────────────────────────────────────────

@app.get("/stats", response_model=schemas.Stats, tags=["Stats"])
def get_stats(current_user=Depends(get_current_user), db: DBSession = Depends(get_db)):
    return crud.get_stats(db, current_user.id)
